Custom Music Mod (Fabric, Minecraft 1.20.1, только клиент)
Сборка: установите JDK 17 и Gradle 8.6+, затем в папке проекта:  gradle build
Готовый мод: build/libs/custom-music-mod-1.0.0.jar  -> в .minecraft/mods (нужен Fabric API 0.92.2+1.20.1)
Остров с названием/исполнителем: ID3-теги и обложка mp3 (для остальных форматов — из имени "Исполнитель - Название").
Клавиша меню по умолчанию M (меняется в Управление -> Custom Music Mod).
Папка .minecraft/CustomMusic создаётся автоматически. Форматы: mp3, ogg, wav, aiff, au.
