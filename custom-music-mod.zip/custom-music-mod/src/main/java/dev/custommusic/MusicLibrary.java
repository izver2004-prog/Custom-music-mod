package dev.custommusic;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

public final class MusicLibrary {
    private static final Set<String> EXT = Set.of("mp3", "ogg", "wav", "aiff", "aif", "au");

    private MusicLibrary() {}

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("CustomMusic");
    }

    public static void ensureDir() {
        try { Files.createDirectories(dir()); } catch (IOException e) {
            CustomMusicMod.LOGGER.warn("Не удалось создать папку CustomMusic", e);
        }
    }

    public static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    /** Все поддерживаемые файлы в папке, по алфавиту. */
    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.filter(Files::isRegularFile)
             .map(p -> p.getFileName().toString())
             .filter(n -> EXT.contains(ext(n)))
             .forEach(out::add);
        } catch (IOException ignored) {}
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Отмеченные галочкой файлы, которые реально есть в папке. */
    public static List<String> selectedExisting(ModConfig cfg) {
        List<String> out = new ArrayList<>();
        for (String n : list()) if (cfg.isSelected(n)) out.add(n);
        return out;
    }
}
