package dev.custommusic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig instance = new ModConfig();

    public boolean vanillaMusic = true;
    public boolean shuffle = false;
    public volatile int delaySeconds = 60;
    public volatile int volume = 100; // %
    public int islandMode = 1; // 0 выкл, 1 при смене трека, 2 всегда
    private List<String> selected = new ArrayList<>();

    public static ModConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("custommusic.json");
    }

    public static void load() {
        Path p = path();
        if (!Files.exists(p)) return;
        try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            ModConfig c = GSON.fromJson(r, ModConfig.class);
            if (c != null) {
                if (c.selected == null) c.selected = new ArrayList<>();
                instance = c;
            }
        } catch (Exception e) {
            CustomMusicMod.LOGGER.warn("Не удалось прочитать конфиг", e);
        }
    }

    public synchronized void save() {
        try (Writer w = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
            GSON.toJson(this, w);
        } catch (Exception e) {
            CustomMusicMod.LOGGER.warn("Не удалось сохранить конфиг", e);
        }
    }

    public synchronized boolean isSelected(String name) { return selected.contains(name); }

    public synchronized boolean hasSelection() { return !selected.isEmpty(); }

    public synchronized void toggle(String name) {
        if (!selected.remove(name)) selected.add(name);
        save();
    }
}
