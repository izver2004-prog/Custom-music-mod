package dev.custommusic;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class MusicScreen extends Screen {
    private final Screen parent;
    private TrackList list;
    private Button pauseBtn;

    public MusicScreen(Screen parent) {
        super(Component.literal("Custom Music Mod"));
        this.parent = parent;
    }

    private static Component vanillaLabel() {
        return Component.literal("Музыка Minecraft: " + (ModConfig.get().vanillaMusic ? "ВКЛ" : "ВЫКЛ"));
    }

    private static Component pauseLabel() {
        return Component.literal(MusicPlayer.INSTANCE.isPaused() ? "▶ Продолжить" : "⏸ Пауза");
    }

    @Override
    protected void init() {
        MusicLibrary.ensureDir();
        list = new TrackList(minecraft, width, height, 40, height - 60);
        list.reload();
        addWidget(list);

        int x = width / 2 - 202;
        int y1 = height - 52, y2 = height - 28;

        addRenderableWidget(Button.builder(vanillaLabel(), b -> {
            ModConfig c = ModConfig.get();
            c.vanillaMusic = !c.vanillaMusic;
            c.save();
            b.setMessage(vanillaLabel());
        }).bounds(x, y1, 170, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Настройки"),
                b -> minecraft.setScreen(new SettingsScreen(this))).bounds(x + 174, y1, 110, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Обновить список"),
                b -> list.reload()).bounds(x + 288, y1, 116, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Открыть папку"),
                b -> Util.getPlatform().openFile(MusicLibrary.dir().toFile())).bounds(x, y2, 98, 20).build());

        pauseBtn = addRenderableWidget(Button.builder(pauseLabel(), b -> {
            MusicPlayer.INSTANCE.setPaused(!MusicPlayer.INSTANCE.isPaused());
            b.setMessage(pauseLabel());
        }).bounds(x + 102, y2, 98, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Следующий ⏭"), b -> {
            MusicPlayer.INSTANCE.ensureStarted();
            MusicPlayer.INSTANCE.next();
            pauseBtn.setMessage(pauseLabel());
        }).bounds(x + 204, y2, 98, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Готово"),
                b -> onClose()).bounds(x + 306, y2, 98, 20).build());
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        list.render(g, mx, my, pt);
        super.render(g, mx, my, pt);

        g.drawCenteredString(font, title, width / 2, 10, 0xFFFFFF);
        String cur = MusicPlayer.INSTANCE.getCurrent();
        Component status = Component.literal(cur != null ? "Сейчас играет: " + cur
                : ModConfig.get().hasSelection() ? "Ожидание следующего трека..." : "Отметьте галочкой треки для воспроизведения");
        g.drawCenteredString(font, status, width / 2, 25, 0xAAAAAA);

        if (list.children().isEmpty()) {
            g.drawCenteredString(font, Component.literal("Папка пуста. Положите сюда .mp3 / .ogg / .wav:"), width / 2, height / 2 - 10, 0xFFFFFF);
            g.drawCenteredString(font, Component.literal(MusicLibrary.dir().toString()), width / 2, height / 2 + 4, 0x55FF55);
        }
    }

    // ---------- список треков ----------
    static final class TrackList extends ContainerObjectSelectionList<TrackList.TrackEntry> {
        TrackList(Minecraft mc, int w, int h, int y0, int y1) { super(mc, w, h, y0, y1, 24); }

        void reload() {
            clearEntries();
            for (String n : MusicLibrary.list()) addEntry(new TrackEntry(n));
        }

        @Override public int getRowWidth() { return 320; }
        @Override protected int getScrollbarPosition() { return width / 2 + 170; }

        static final class TrackEntry extends ContainerObjectSelectionList.Entry<TrackEntry> {
            private final String name;
            private final Button box;

            TrackEntry(String name) {
                this.name = name;
                this.box = Button.builder(label(name), b -> {
                    ModConfig.get().toggle(name);
                    b.setMessage(label(name));
                    MusicPlayer.INSTANCE.ensureStarted();
                    MusicPlayer.INSTANCE.wake();
                }).bounds(0, 0, 20, 20).build();
            }

            private static Component label(String name) {
                return Component.literal(ModConfig.get().isSelected(name) ? "✔" : "");
            }

            @Override
            public void render(GuiGraphics g, int idx, int top, int left, int w, int h,
                               int mx, int my, boolean hover, float pt) {
                Minecraft mc = Minecraft.getInstance();
                boolean playing = name.equals(MusicPlayer.INSTANCE.getCurrent());
                g.drawString(mc.font, mc.font.plainSubstrByWidth(name, w - 40), left + 4, top + 6,
                        playing ? 0x55FF55 : 0xFFFFFF);
                box.setX(left + w - 22);
                box.setY(top + 1);
                box.render(g, mx, my, pt);
            }

            @Override public List<? extends GuiEventListener> children() { return List.of(box); }
            @Override public List<? extends NarratableEntry> narratables() { return List.of(box); }
        }
    }
}
