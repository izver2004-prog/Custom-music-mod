package dev.custommusic;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SettingsScreen extends Screen {
    private static final int[] PRESETS = {0, 10, 30, 60, 120, 300, 600};
    private final Screen parent;
    private Button delayBtn;
    private EditBox edit;

    public SettingsScreen(Screen parent) {
        super(Component.literal("Настройки Custom Music"));
        this.parent = parent;
    }

    private static Component delayLabel() {
        int d = ModConfig.get().delaySeconds;
        return Component.literal("Пауза между треками: " + (d == 0 ? "нет" : d + " с"));
    }

    private static Component shuffleLabel() {
        return Component.literal("Порядок: " + (ModConfig.get().shuffle ? "случайный" : "по списку"));
    }

    private static Component islandLabel() {
        String[] n = {"выкл", "при смене трека", "всегда"};
        return Component.literal("Остров сверху: " + n[ModConfig.get().islandMode]);
    }

    @Override
    protected void init() {
        ModConfig cfg = ModConfig.get();
        int x = width / 2 - 100;
        int y = height / 4;

        delayBtn = addRenderableWidget(Button.builder(delayLabel(), b -> {
            int cur = cfg.delaySeconds, nxt = PRESETS[0];
            for (int p : PRESETS) if (p > cur) { nxt = p; break; }
            cfg.delaySeconds = nxt;
            edit.setValue(String.valueOf(nxt));
            b.setMessage(delayLabel());
        }).bounds(x, y, 200, 20).build());

        edit = new EditBox(font, x + 120, y + 28, 80, 20, Component.empty());
        edit.setFilter(s -> s.matches("\\d{0,5}"));
        edit.setValue(String.valueOf(cfg.delaySeconds));
        edit.setResponder(s -> {
            if (s.isEmpty()) return;
            cfg.delaySeconds = Math.min(86400, Integer.parseInt(s));
            delayBtn.setMessage(delayLabel());
        });
        addRenderableWidget(edit);

        addRenderableWidget(Button.builder(shuffleLabel(), b -> {
            cfg.shuffle = !cfg.shuffle;
            b.setMessage(shuffleLabel());
        }).bounds(x, y + 56, 200, 20).build());

        addRenderableWidget(new AbstractSliderButton(x, y + 84, 200, 20, Component.empty(), cfg.volume / 100.0) {
            { updateMessage(); }
            @Override protected void updateMessage() {
                setMessage(Component.literal("Громкость: " + (int) Math.round(value * 100) + "%"));
            }
            @Override protected void applyValue() { cfg.volume = (int) Math.round(value * 100); }
        });

        addRenderableWidget(Button.builder(islandLabel(), b -> {
            cfg.islandMode = (cfg.islandMode + 1) % 3;
            b.setMessage(islandLabel());
        }).bounds(x, y + 112, 200, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(x, y + 148, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        super.render(g, mx, my, pt);
        g.drawCenteredString(font, title, width / 2, 15, 0xFFFFFF);
        g.drawString(font, "Своё значение (сек):", width / 2 - 100, height / 4 + 34, 0xDDDDDD);
    }

    @Override
    public void removed() { ModConfig.get().save(); }

    @Override
    public void onClose() { minecraft.setScreen(parent); }
}
