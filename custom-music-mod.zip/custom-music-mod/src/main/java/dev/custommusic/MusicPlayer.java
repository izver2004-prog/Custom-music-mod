package dev.custommusic;

import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import java.nio.file.Path;
import java.util.List;
import java.util.Random;

/**
 * Один фоновый поток с минимальным приоритетом. Когда музыка не играет — просыпается раз в 250–1000 мс.
 * Во время игры декодирует кусочки по 8 КБ и пишет их в аудиолинию (она сама тормозит поток).
 */
public final class MusicPlayer {
    public static final MusicPlayer INSTANCE = new MusicPlayer();

    private final Object lock = new Object();
    private final Random rnd = new Random();
    private Thread thread;
    private volatile boolean skip, paused;
    private volatile String current;
    private volatile TrackMeta meta;
    private volatile long startedAt;
    private int seq = -1;
    private String last;

    private MusicPlayer() {}

    public synchronized void ensureStarted() {
        if (thread != null && thread.isAlive()) return;
        thread = new Thread(this::loop, "CustomMusic-Player");
        thread.setDaemon(true);
        thread.setPriority(Thread.MIN_PRIORITY);
        thread.start();
    }

    public void wake() { synchronized (lock) { lock.notifyAll(); } }
    public void next() { skip = true; paused = false; wake(); }
    public void setPaused(boolean p) { paused = p; wake(); }
    public boolean isPaused() { return paused; }
    public String getCurrent() { return current; }
    public TrackMeta getMeta() { return meta; }
    public long getStartedAt() { return startedAt; }
    /** Играет ли сейчас наша музыка (нужно, чтобы заглушать ванильную). */
    public boolean isPlaying() { return current != null && !paused; }

    private void pause(long ms) throws InterruptedException {
        synchronized (lock) { lock.wait(ms); }
    }

    private void loop() {
        while (true) {
            try {
                ModConfig cfg = ModConfig.get();
                List<String> tracks = MusicLibrary.selectedExisting(cfg);
                if (tracks.isEmpty()) { current = null; pause(1000); continue; }

                String name = pick(tracks);
                skip = false;
                meta = TrackMeta.read(MusicLibrary.dir().resolve(name));
                startedAt = System.currentTimeMillis();
                current = name;
                boolean ok = play(MusicLibrary.dir().resolve(name), name);
                current = null;

                if (!ok) { pause(3000); continue; }
                if (skip || !cfg.isSelected(name)) { skip = false; continue; }

                long end = System.nanoTime() + cfg.delaySeconds * 1_000_000_000L;
                while (!skip && System.nanoTime() < end) pause(250);
            } catch (InterruptedException e) {
                return;
            } catch (Throwable t) {
                CustomMusicMod.LOGGER.warn("Ошибка плеера", t);
                current = null;
                try { pause(3000); } catch (InterruptedException e) { return; }
            }
        }
    }

    private String pick(List<String> tracks) {
        String name;
        if (ModConfig.get().shuffle) {
            name = tracks.get(rnd.nextInt(tracks.size()));
            if (tracks.size() > 1) while (name.equals(last)) name = tracks.get(rnd.nextInt(tracks.size()));
        } else {
            seq = (seq + 1) % tracks.size();
            name = tracks.get(seq);
        }
        last = name;
        return name;
    }

    private boolean play(Path file, String name) {
        ModConfig cfg = ModConfig.get();
        try (PcmSource src = PcmSource.open(file)) {
            AudioFormat fmt = src.format();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, fmt);
            try (SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info)) {
                line.open(fmt, 1 << 16);
                line.start();
                byte[] buf = new byte[8192];
                int n;
                while (!skip && cfg.isSelected(name) && (n = src.read(buf)) > 0) {
                    if (paused) {
                        line.stop();
                        while (paused && !skip) Thread.sleep(100);
                        line.start();
                        if (skip) break;
                    }
                    applyVolume(buf, n);
                    line.write(buf, 0, n);
                }
                if (skip || !cfg.isSelected(name)) line.flush(); else line.drain();
            }
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return true;
        } catch (Throwable t) {
            CustomMusicMod.LOGGER.warn("Не удалось проиграть " + name, t);
            return false;
        }
    }

    private static float volume() {
        float v = ModConfig.get().volume / 100f;
        Minecraft mc = Minecraft.getInstance();
        if (mc != null && mc.options != null) {
            v *= mc.options.getSoundSourceVolume(SoundSource.MASTER)
               * mc.options.getSoundSourceVolume(SoundSource.MUSIC);
        }
        return v;
    }

    private static void applyVolume(byte[] b, int n) {
        float v = volume();
        if (v >= 0.999f) return;
        for (int i = 0; i + 1 < n; i += 2) {
            short s = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
            s = (short) (s * v);
            b[i] = (byte) s;
            b[i + 1] = (byte) (s >> 8);
        }
    }
}
