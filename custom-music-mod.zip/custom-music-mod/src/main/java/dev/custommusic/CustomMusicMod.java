package dev.custommusic;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomMusicMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("CustomMusic");
    private static KeyMapping openKey;
    private static boolean started;

    @Override
    public void onInitializeClient() {
        System.setProperty("java.awt.headless", "true"); // ImageIO без AWT-окон
        ModConfig.load();
        MusicLibrary.ensureDir(); // папка создаётся сама

        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.custommusic.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, "key.categories.custommusic"));

        HudRenderCallback.EVENT.register(MusicIsland::render);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!started) {
                started = true;
                if (ModConfig.get().hasSelection()) MusicPlayer.INSTANCE.ensureStarted();
            }
            while (openKey.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new MusicScreen(null));
            }
            // Ванильную музыку глушим, если выключена или сейчас играет наша
            if (!ModConfig.get().vanillaMusic || MusicPlayer.INSTANCE.isPlaying()) {
                mc.getMusicManager().stopPlaying();
            }
        });
    }
}
