package dev.custommusic;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Arrays;

/** Название, исполнитель и обложка (ID3 для mp3; для остальных форматов — из имени файла). */
public final class TrackMeta {
    public static final int SIZE = 32;
    public final String title;
    public final String artist;
    /** ARGB 32x32 или null, если обложки нет */
    public final int[] cover;

    private TrackMeta(String title, String artist, int[] cover) {
        this.title = title;
        this.artist = artist;
        this.cover = cover;
    }

    public static TrackMeta read(Path file) {
        String name = file.getFileName().toString();
        String title = null, artist = null;
        int[] cover = null;

        if ("mp3".equals(MusicLibrary.ext(name))) {
            try (RandomAccessFile f = new RandomAccessFile(file.toFile(), "r")) {
                String[] txt = new String[2];
                byte[][] pic = new byte[1][];
                try { parseV2(f, txt, pic); } catch (Exception ignored) {}
                title = txt[0];
                artist = txt[1];
                if (pic[0] != null) {
                    try { cover = decodeCover(pic[0]); } catch (Throwable ignored) {}
                }
                if ((title == null || title.isEmpty()) && f.length() > 128) {
                    f.seek(f.length() - 128);
                    byte[] t = new byte[128];
                    f.readFully(t);
                    if (t[0] == 'T' && t[1] == 'A' && t[2] == 'G') {
                        title = new String(t, 3, 30, StandardCharsets.ISO_8859_1).replace("\0", "").trim();
                        artist = new String(t, 33, 30, StandardCharsets.ISO_8859_1).replace("\0", "").trim();
                    }
                }
            } catch (Exception ignored) {}
        }

        if (title == null || title.isEmpty()) {
            String base = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name;
            base = base.replace('_', ' ').trim();
            int i = base.indexOf(" - ");
            if (i > 0) {
                if (artist == null || artist.isEmpty()) artist = base.substring(0, i).trim();
                title = base.substring(i + 3).trim();
            } else {
                title = base;
            }
        }
        if (artist == null || artist.isEmpty()) artist = "Неизвестный исполнитель";
        return new TrackMeta(title, artist, cover);
    }

    // ---------- ID3v2 ----------
    private static void parseV2(RandomAccessFile f, String[] txt, byte[][] pic) throws IOException {
        byte[] h = new byte[10];
        f.seek(0);
        if (f.read(h) < 10 || h[0] != 'I' || h[1] != 'D' || h[2] != '3') return;
        int ver = h[3] & 0xFF, flags = h[5] & 0xFF;
        int size = synch(h, 6);
        if (size <= 0 || size > 16_000_000) return;
        byte[] d = new byte[size];
        f.readFully(d);

        int p = 0;
        if (ver >= 3 && (flags & 0x40) != 0 && size >= 4) p = ver == 4 ? synch(d, 0) : be32(d, 0) + 4;
        int idLen = ver == 2 ? 3 : 4, hdr = ver == 2 ? 6 : 10;

        while (p + hdr <= size) {
            if (d[p] == 0) break;
            String id = new String(d, p, idLen, StandardCharsets.ISO_8859_1);
            int fs = ver == 2 ? ((d[p + 3] & 0xFF) << 16 | (d[p + 4] & 0xFF) << 8 | (d[p + 5] & 0xFF))
                    : ver == 4 ? synch(d, p + 4) : be32(d, p + 4);
            int start = p + hdr;
            if (fs <= 0 || start + fs > size) break;
            switch (id) {
                case "TIT2", "TT2" -> txt[0] = text(d, start, fs);
                case "TPE1", "TP1" -> txt[1] = text(d, start, fs);
                case "APIC", "PIC" -> { if (pic[0] == null) pic[0] = apic(d, start, fs, ver == 2); }
                default -> {}
            }
            p = start + fs;
        }
    }

    private static int synch(byte[] b, int o) {
        return (b[o] & 0x7F) << 21 | (b[o + 1] & 0x7F) << 14 | (b[o + 2] & 0x7F) << 7 | (b[o + 3] & 0x7F);
    }

    private static int be32(byte[] b, int o) {
        return (b[o] & 0xFF) << 24 | (b[o + 1] & 0xFF) << 16 | (b[o + 2] & 0xFF) << 8 | (b[o + 3] & 0xFF);
    }

    private static Charset charset(int enc) {
        return switch (enc) {
            case 1 -> StandardCharsets.UTF_16;
            case 2 -> StandardCharsets.UTF_16BE;
            case 3 -> StandardCharsets.UTF_8;
            default -> StandardCharsets.ISO_8859_1;
        };
    }

    private static String text(byte[] d, int s, int len) {
        String t = new String(d, s + 1, len - 1, charset(d[s]));
        int z = t.indexOf('\0');
        if (z >= 0) t = t.substring(0, z);
        return t.trim();
    }

    private static byte[] apic(byte[] d, int s, int len, boolean v22) {
        int end = s + len, enc = d[s], i = s + 1;
        if (v22) i += 3;
        else { while (d[i] != 0) i++; i++; }
        i++; // тип картинки
        if (enc == 0 || enc == 3) { while (d[i] != 0) i++; i++; }
        else { while (i + 1 < end && !(d[i] == 0 && d[i + 1] == 0)) i += 2; i += 2; }
        return i < end ? Arrays.copyOfRange(d, i, end) : null;
    }

    /** Без AWT Graphics (на macOS это конфликтует с GLFW): ручное масштабирование. */
    private static int[] decodeCover(byte[] data) throws IOException {
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
        if (img == null) return null;
        int w = img.getWidth(), h = img.getHeight(), s = Math.min(w, h);
        int ox = (w - s) / 2, oy = (h - s) / 2;
        int[] out = new int[SIZE * SIZE];
        for (int y = 0; y < SIZE; y++)
            for (int x = 0; x < SIZE; x++)
                out[y * SIZE + x] = img.getRGB(ox + x * s / SIZE, oy + y * s / SIZE) | 0xFF000000;
        return out;
    }
}
