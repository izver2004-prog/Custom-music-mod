package dev.custommusic;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/** «Динамический остров» сверху экрана: иконка/обложка слева, название сверху, исполнитель снизу. */
public final class MusicIsland {
    private static final int MAX_TEXT = 140, FULL_H = 30, MIN_W = 36, MIN_H = 12, TOP = 4;
    private static float anim;
    private static long lastNs;
    private static TrackMeta shown, texFor;
    private static ResourceLocation tex;

    private MusicIsland() {}

    public static void render(GuiGraphics g, float tickDelta) {
        Minecraft mc = Minecraft.getInstance();
        ModConfig cfg = ModConfig.get();
        MusicPlayer pl = MusicPlayer.INSTANCE;

        TrackMeta cur = pl.getCurrent() != null ? pl.getMeta() : null;
        boolean want = false;
        if (cur != null) {
            shown = cur;
            want = cfg.islandMode == 2
                    || (cfg.islandMode == 1 && System.currentTimeMillis() - pl.getStartedAt() < 6000);
        }

        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0 : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float target = want ? 1f : 0f;
        anim = anim < target ? Math.min(target, anim + dt * 4f) : Math.max(target, anim - dt * 4f);

        if (anim <= 0.001f || shown == null || mc.options.hideGui) return;

        Font font = mc.font;
        String title = fit(font, shown.title);
        String artist = fit(font, shown.artist);
        int textW = Math.max(font.width(title), font.width(artist));
        int fullW = 4 + 22 + 6 + textW + 12;

        float e = 1f - (1f - anim) * (1f - anim) * (1f - anim);
        int w = Math.round(MIN_W + (fullW - MIN_W) * e);
        int h = Math.round(MIN_H + (FULL_H - MIN_H) * e);
        int x = (g.guiWidth() - w) / 2;
        fillRounded(g, x, TOP, w, h, h / 2, 0xF2000000);

        if (anim > 0.85f) {
            int a = Math.max(4, Math.round((anim - 0.85f) / 0.15f * 255f));
            int ix = x + 4, iy = TOP + 4;
            ensureTexture(mc);
            if (tex != null) {
                g.blit(tex, ix, iy, 22, 22, 0f, 0f, TrackMeta.SIZE, TrackMeta.SIZE, TrackMeta.SIZE, TrackMeta.SIZE);
            } else {
                fillRounded(g, ix, iy, 22, 22, 5, 0xFF3A3A3C);
                g.drawCenteredString(font, "♪", ix + 11, iy + 7, 0xFFFFFF);
            }
            g.drawString(font, title, x + 32, TOP + 6, (a << 24) | 0xFFFFFF, false);
            g.drawString(font, artist, x + 32, TOP + 16, (a << 24) | 0xAAAAAA, false);
        }
    }

    private static String fit(Font font, String s) {
        if (font.width(s) <= MAX_TEXT) return s;
        return font.plainSubstrByWidth(s, MAX_TEXT - font.width("…")) + "…";
    }

    private static void ensureTexture(Minecraft mc) {
        if (texFor == shown) return;
        if (tex != null) { mc.getTextureManager().release(tex); tex = null; }
        texFor = shown;
        if (shown.cover == null) return;
        NativeImage img = new NativeImage(TrackMeta.SIZE, TrackMeta.SIZE, false);
        for (int y = 0; y < TrackMeta.SIZE; y++) {
            for (int x = 0; x < TrackMeta.SIZE; x++) {
                int argb = shown.cover[y * TrackMeta.SIZE + x];
                int abgr = (argb & 0xFF00FF00) | ((argb >> 16) & 0xFF) | ((argb & 0xFF) << 16);
                img.setPixelRGBA(x, y, abgr);
            }
        }
        tex = mc.getTextureManager().register("custommusic_cover", new DynamicTexture(img));
    }

    private static void fillRounded(GuiGraphics g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        g.fill(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, c);
        }
    }
}
