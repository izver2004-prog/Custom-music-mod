package dev.custommusic;

import com.mojang.blaze3d.audio.OggAudioStream;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Потоковый источник 16-bit PCM (little-endian). Декодирует по кусочкам — память почти не тратится. */
public interface PcmSource extends AutoCloseable {
    AudioFormat format();

    /** @return число байт или -1 в конце */
    int read(byte[] buf) throws IOException;

    @Override
    void close();

    static PcmSource open(Path file) throws Exception {
        String ext = MusicLibrary.ext(file.getFileName().toString());
        switch (ext) {
            case "mp3": return new Mp3(new BufferedInputStream(Files.newInputStream(file), 1 << 16));
            case "ogg": return new Ogg(new BufferedInputStream(Files.newInputStream(file), 1 << 16));
            default:    return new Wav(file.toFile());
        }
    }

    final class Mp3 implements PcmSource {
        private final Bitstream bs;
        private final Decoder dec = new Decoder();
        private final AudioFormat fmt;
        private byte[] pcm = new byte[0];
        private int pos, len;

        Mp3(InputStream in) throws Exception {
            bs = new Bitstream(in);
            if (!decodeNext()) throw new IOException("Пустой mp3");
            fmt = new AudioFormat(dec.getOutputFrequency(), 16, dec.getOutputChannels(), true, false);
        }

        private boolean decodeNext() throws IOException {
            try {
                Header h = bs.readFrame();
                if (h == null) return false;
                SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                short[] s = sb.getBuffer();
                int n = sb.getBufferLength();
                if (pcm.length < n * 2) pcm = new byte[n * 2];
                for (int i = 0, j = 0; i < n; i++) {
                    pcm[j++] = (byte) s[i];
                    pcm[j++] = (byte) (s[i] >> 8);
                }
                len = n * 2;
                pos = 0;
                bs.closeFrame();
                return true;
            } catch (Exception e) {
                throw new IOException(e);
            }
        }

        public AudioFormat format() { return fmt; }

        public int read(byte[] b) throws IOException {
            if (pos >= len && !decodeNext()) return -1;
            int c = Math.min(b.length, len - pos);
            System.arraycopy(pcm, pos, b, 0, c);
            pos += c;
            return c;
        }

        public void close() { try { bs.close(); } catch (Exception ignored) {} }
    }

    final class Ogg implements PcmSource {
        private final OggAudioStream stream;
        private ByteBuffer cur;

        Ogg(InputStream in) throws IOException { stream = new OggAudioStream(in); }

        public AudioFormat format() { return stream.getFormat(); }

        public int read(byte[] b) throws IOException {
            if (cur == null || !cur.hasRemaining()) cur = stream.read(b.length);
            if (cur == null || !cur.hasRemaining()) return -1;
            int c = Math.min(b.length, cur.remaining());
            cur.get(b, 0, c);
            return c;
        }

        public void close() { try { stream.close(); } catch (Exception ignored) {} }
    }

    final class Wav implements PcmSource {
        private final AudioInputStream in;

        Wav(File f) throws Exception {
            AudioInputStream raw = AudioSystem.getAudioInputStream(f);
            AudioFormat b = raw.getFormat();
            AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, b.getSampleRate(), 16,
                    b.getChannels(), b.getChannels() * 2, b.getSampleRate(), false);
            in = AudioSystem.getAudioInputStream(target, raw);
        }

        public AudioFormat format() { return in.getFormat(); }
        public int read(byte[] b) throws IOException { return in.read(b); }
        public void close() { try { in.close(); } catch (Exception ignored) {} }
    }
}
